package Tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertFalse;

import org.junit.Before;
import org.junit.Test;


public class TestStack {
    
    Stack<String> stringStack;
    Stack<Integer> intStack;

    
}
