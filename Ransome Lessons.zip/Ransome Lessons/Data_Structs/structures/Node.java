package structures;


/*
  have a variable respresenting a datatype.
  dataType variableName = data;

 class == defining a dataType

 */
public class Node<DataType>{
    
    //private DataType data;


    private DataType data;
    private Node<DataType> inFront;
    private Node<DataType> behind;
    private int index;

    // constructor
    public Node(){

    }

    public Node(DataType d){
        this.data = d;
    }
    //-------------------


    //---------methods------------


    public DataType getData(){
        return this.data;
    }

    public void setData(DataType d){
        this.data = d;
    }

    public void setIndex(int indx){
        this.index = indx;
    }

    public int getIndex(){
        return this.index;
    }

    //------------------

}