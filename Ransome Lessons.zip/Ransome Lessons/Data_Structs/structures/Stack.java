
public class Stack <Data>{

    //3 attributes for a stack
    private int size;
    private Node<Data> top;
    private Node<Data> bottom;

    // the constructor
    public Stack(){
        //empty
    }

    public Stack(Data anything){
        this.size = 1;
        this.top.setData(anything);
        this.bottom.setData(anything);
        this.top.setIndex(0);
        this.bottom.setIndex(0);
    }

    //------methods of our stack-------

    
    public int getSize(){
        return this.size;
    }
    
    public void push(Data newData){
        Node<Data> newNode = new Node(newData);
        if(size == 0){
            this.top = newNode;
            this.top.setIndex(0);
            this.bottom = this.top;
            this.size = 1;
        }
        //---------this was the end------------
        else {
            
        }
    }
}
